package com.google.instantdecision;

/**
 * Created by chenyuheng on 12/16/14.
 */
public class Option {
    private String title;
    private String id;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
