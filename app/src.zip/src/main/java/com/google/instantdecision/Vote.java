package com.google.instantdecision;

import java.util.ArrayList;

/**
 * Created by chenyuheng on 12/16/14.
 */
public class Vote {

    private String id;

    public Vote(String id) {
        this.id = id;
    }
    private String title;
    private boolean multiSelect;
    private int numTicket;
    private ArrayList<Ticket> tickets = new ArrayList<>();
    private ArrayList<Option> options = new ArrayList<>();

    public boolean isMultiSelect() {
        return multiSelect;
    }

    public ArrayList<Ticket> getTickets() {
        return tickets;
    }

    public void setMultiSelect(boolean multiSelect) {
        this.multiSelect = multiSelect;
    }

    public int getNumTicket() {
        return numTicket;
    }

    public void setNumTicket(int numTicket) {
        this.numTicket = numTicket;
    }

    public ArrayList<Option> getOptions() {
        return options;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
