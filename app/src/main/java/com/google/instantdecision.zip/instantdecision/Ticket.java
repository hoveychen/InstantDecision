package com.google.instantdecision;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by chenyuheng on 12/16/14.
 */
public class Ticket {
    private Identify identify = new Identify();
    private Selection selection;

    public Ticket(boolean multiSelect) {
        if (multiSelect) {
            selection = new MultipleSelection();
        } else {
            selection = new SingleSelection();
        }
    }

    public Selection getSelection() {
        return selection;
    }
}
