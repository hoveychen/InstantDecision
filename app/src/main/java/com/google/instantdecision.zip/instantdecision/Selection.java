package com.google.instantdecision;

import java.util.List;

/**
 * Created by chenyuheng on 12/16/14.
 */
public interface Selection {
    public void addSelection(Option candidate);

    public List<Option> getSelections();
}
