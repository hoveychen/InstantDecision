package com.google.instantdecision;

import android.media.Image;

/**
 * Created by chenyuheng on 12/16/14.
 */
public class Identify {
    private String deviceId;
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }
}
