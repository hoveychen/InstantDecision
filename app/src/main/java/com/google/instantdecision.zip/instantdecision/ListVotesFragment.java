package com.google.instantdecision;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Random;


public class ListVotesFragment extends Fragment {

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment ListVotesFragment.
     */
    public static ListVotesFragment newInstance() {
        ListVotesFragment fragment = new ListVotesFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    public ListVotesFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_list_votes, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        TextView userIdView = (TextView) getView().findViewById(R.id.user_id_label);
        userIdView.setText(((MainActivity)getActivity()).getUserId());
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    public static ArrayList<Vote> createMockVotes() {
        ArrayList<Vote> votes = new ArrayList<>();
        votes.add(createMockVote("today"));
        votes.add(createMockVote("tomorrow"));
        return votes;
    }

    public static Vote createMockVote(String title) {
        Vote vote = new Vote(Long.toString(new Random().nextLong()));
        vote.setNumTicket(10);
        vote.setTitle(title);
        vote.setMultiSelect(true);

        Option option1 = createCandidate("opt1", "Eat dinner");
        Option option2 = createCandidate("opt2", "Don't eat dinner");
        Option option3 = createCandidate("opt3", "No idea");

        vote.getOptions().add(option1);
        vote.getOptions().add(option2);
        vote.getOptions().add(option3);

        vote.getTickets().add(createMockTicket("Yuheng", option1));
        vote.getTickets().add(createMockTicket("Xiaoqin", option1));
        vote.getTickets().add(createMockTicket("zZb", option2));
        vote.getTickets().add(createMockTicket("Zhiyuwang", option3));
        return vote;
    }

    public static Option createCandidate(String title, String description) {
        Option candidate = new Option();

        candidate.setTitle(title);
        return candidate;
    }

    public static Ticket createMockTicket(String id, Option selected) {
        Ticket ticket = new Ticket(false);
        Identify identify = new Identify();
        identify.setName(id);
        ticket.setId(identify);
        ticket.getSelection().addSelection(selected);
        return ticket;
    }
}
